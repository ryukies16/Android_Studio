package com.coronavirus;
import android.widget.ArrayAdapter                                                     ;
import android.content.Context;
import java.util.List;
import android.widget.Adapter;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.widget.TextView;

public class java_adapter extends ArrayAdapter<model>{
	private Context context;
	private List<model> modelist;
	
	public java_adapter(Context context , List<model> modelist){
		super(context,R.layout.testing,modelist);
		
		this.context =context;
		this.modelist =modelist;
		
	}

	@NonNull
	@Override
	public View getView(int position, @Nullable View convertView,@NonNull ViewGroup parent)
	{
		View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.testing,null,true);
		
		TextView state = v.findViewById(R.id.state);
		TextView active = v.findViewById(R.id.active);
		TextView cured = v.findViewById(R.id.cured);
		TextView death = v.findViewById(R.id.death);
		TextView total = v.findViewById(R.id.total);
		TextView inactive = v.findViewById(R.id.incactive);
		TextView inccured = v.findViewById(R.id.inccured);
		TextView incdeath = v.findViewById(R.id.incdeath);
		
		
		state.setText(modelist.get(position).getName());
		active.setText(modelist.get(position).getactive());
		cured.setText(modelist.get(position).getcured());
		
		death.setText(modelist.get(position).getDeath());
		total.setText(modelist.get(position).getTotal());
		inactive.setText(modelist.get(position).getIncAct());
		inccured.setText(modelist.get(position).getIncRec());
		incdeath.setText(modelist.get(position).getIncDec());
		
		
		
		return v;
	}
	
	
	
}

