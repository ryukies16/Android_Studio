package com.Exer3HerodaMarvinTerence;


	import android.app.*;
	import android.os.*;
	import android.widget.*;
	import android.widget.SearchView.*;
	import android.view.View.*;
	import android.widget.Button;
	import android.widget.Toast;
	import android.view.*;

	public class MainActivity extends Activity 
	{
		EditText edtxt;
		Button btn;
		TextView txtv;



		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.main);

			edtxt = (EditText)findViewById(R.id.edittxt);
			btn = (Button)findViewById(R.id.btn);
			txtv = (TextView)findViewById(R.id.txtv);

			btn.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View view){
						txtv.setText(txtv.getText());
						int x = Integer.parseInt(edtxt.getText().toString());
						int num1 = x%10;
						int num2 = x/10;
						int num3 = num2%10;
						int num4 = num2/10;
						int num5 = num4%10;

						int arm = ((num1*num1*num1)+(num3*num3*num3)+(num5*num5*num5));

						if(arm == x){
							Toast.makeText(getApplicationContext(),"Armstrong Number",Toast.LENGTH_LONG).show();
							txtv.setText("Armstrong Number");

						}
						else{
							Toast.makeText(getApplicationContext(),"Not Armstrong Number",Toast.LENGTH_LONG).show();
							txtv.setText("Not Armstrong Number");
						}


					}


				});





		}


	}
