package com.Exe2HERODAMARVINTERENCE;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.Toast.*;
import android.content.*;
import org.w3c.dom.*;
import android.view.View.*;

public class MainActivity extends Activity 
{
	Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bplus,bminus,bmultiply,bdiv,bdel,bequal,bdot                ;
	EditText edtxt1;
	 
    float fvalue,svalue;
	
	boolean badd,bsub,btim,bdivide;
	
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		b1 = (Button)findViewById(R.id.Cone);
		b2 = findViewById(R.id.Ctwo);
		b3 = (Button)findViewById(R.id.Cthree);
		b4 = (Button)findViewById(R.id.Cfour);
		b5 = (Button)findViewById(R.id.Cfive);
		b6 = (Button)findViewById(R.id.Csix);
		b7 = (Button)findViewById(R.id.Cseven);
		b8 = findViewById(R.id.Ceight);
		b9 = (Button)findViewById(R.id.Cnine);
		b0 = (Button)findViewById(R.id.Czero);
		bplus = (Button)findViewById(R.id.Cplus);
		bminus = (Button)findViewById(R.id.Cminus);
		bmultiply = (Button)findViewById(R.id.Cmultiply);
		bdiv = (Button)findViewById(R.id.Cdivide);
		bdot = (Button)findViewById(R.id.Cdot);
		bdel = (Button)findViewById(R.id.Cdel);
		bequal = (Button)findViewById(R.id.Cequal);
		edtxt1 = (EditText)findViewById(R.id.edtview);
		
		b1.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "1");
							
							// TODO: Implement this method
						}
					
			
		});
		
		b2.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "2");

							// TODO: Implement this method
						}


				});
		b3.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "3");

							// TODO: Implement this method
						}


				});
		b4.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "4");

							// TODO: Implement this method
						}


				});
		b5.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "5");

							// TODO: Implement this method
						}


				});
		b6.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "6");

							// TODO: Implement this method
						}


				});
		b7.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "7");

							// TODO: Implement this method
						}


				});
				
		b8.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "8");

							// TODO: Implement this method
						}


				});
		b9.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "9");

							// TODO: Implement this method
						}


				});
				
		b0.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + "0");

							// TODO: Implement this method
						}


				});
				
		bplus.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							if (edtxt1 == null){
									edtxt1.setText("");


								}
							else{

									fvalue = Float.parseFloat(edtxt1.getText()+"");
									badd = true;
									edtxt1.setText(null);

								}
						}
				});

		bminus.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							fvalue = Float.parseFloat(edtxt1.getText() + "");
							bsub = true;
							edtxt1.setText(null);

						}
				});

		bmultiply.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							fvalue = Float.parseFloat(edtxt1.getText() + "");
							btim = true;
							edtxt1.setText(null);

						}
				});

		bdiv.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							fvalue = Float.parseFloat(edtxt1.getText() + "");
							bdivide = true;
							edtxt1.setText(null);

						}
				});

		bequal.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							svalue = Float.parseFloat(edtxt1.getText() + "");
							if (badd == true){
									edtxt1.setText(fvalue + svalue +"");
									badd = false;

								}
							if (bsub == true){
									edtxt1.setText(fvalue - svalue +"");
									bsub = false;
								}
							if (btim == true){
									edtxt1.setText(fvalue * svalue +"");
									btim = false;
								}
							if (bdivide == true){
									edtxt1.setText(fvalue / svalue +"");
									bdivide = false;		
								}
						}




				});

		bdel.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText("");
						}



				});
		bdot.setOnClickListener(new View.OnClickListener(){

					@Override
					public void onClick(View view)
						{
							edtxt1.setText(edtxt1.getText() + ".");

						}



				});



		
		
				
		}
		public void onone (View view){
			Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
		}
	
		public void ontwo(View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onthree(View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onfour (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onfive (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		
		public void onsix(View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onseven (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void oneight (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onnine (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onzero (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onplus (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onmin (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onmul (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		
		public void ondiv (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void ondot (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void ondel (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		public void onequal (View view){
				Toast.makeText(this,("1"),Toast.LENGTH_LONG).show();
			}
		
			
			
			
}

