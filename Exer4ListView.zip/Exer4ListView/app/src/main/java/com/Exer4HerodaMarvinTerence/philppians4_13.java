package com.Exer4HerodaMarvinTerence;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class philppians4_13 extends Activity

	{
    ImageView phil;
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.phil413);
				phil = findViewById(R.id.phil413);
				
			}
			public void onphil (View view)
			{
				Toast.makeText(this,"Jesus is our strenghts", Toast.LENGTH_LONG).show();
			}
	
	
}
