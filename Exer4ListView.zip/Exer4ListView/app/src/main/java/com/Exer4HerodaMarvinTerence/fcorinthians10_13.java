package com.Exer4HerodaMarvinTerence;
import android.app.*;
import android.os.*;
import android.widget.*;
import org.apache.http.conn.util.*;
import android.view.*;

public class fcorinthians10_13 extends Activity

	{
        ImageView llout;
		
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.fcor1013);
				
				llout =(ImageView) findViewById(R.id.cor1013);
	
			}
			public void onclickimages (View view){
				Toast.makeText(this,"God's help you to succeed",Toast.LENGTH_LONG).show();
				
			};
	
	
}
