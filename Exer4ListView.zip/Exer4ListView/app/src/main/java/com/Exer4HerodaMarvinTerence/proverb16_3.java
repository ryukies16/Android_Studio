package com.Exer4HerodaMarvinTerence;
import android.app.*;
import android.view.View.*;
import android.view.*;
import android.os.*;
import android.widget.*;

public class proverb16_3 extends Activity
	{
      ImageView imgprov;
		
		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.proverbs316);
				imgprov = findViewById(R.id.prov316);
			}
			public void onprov (View view){
				Toast.makeText(this,"Commit to God for the successful future", Toast.LENGTH_LONG).show();
				
			}
	
	
}
