package com.Exer4HerodaMarvinTerence;
import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.widget.Toast;

public class exodus14_14 extends Activity
	{
		ImageView llexo;

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.exodus1414);
			llexo = findViewById(R.id.exo1414);
			
			
				
			}
	
	public void Onexod (View view){
		Toast.makeText(this,"We will never been lose",Toast.LENGTH_LONG).show();
	}

}

