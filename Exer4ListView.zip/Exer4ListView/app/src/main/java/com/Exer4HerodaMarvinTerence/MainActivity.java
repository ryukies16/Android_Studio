package com.Exer4HerodaMarvinTerence;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.widget.AdapterView.*;
import android.view.*;
import android.content.*;

public class MainActivity extends Activity 
{
	ListView list;
	String [] Myverse = {"Exodus14:14","Proverbs16:3","1Corinthians10:13","Proverbs3:5","Philippians4:19"};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this , R.layout.simple,Myverse);
		ListView list = findViewById(R.id.list1);
		list.setAdapter(adapter);
		
		list.setOnItemClickListener(new AdapterView.OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent,View view , int position ,long id)
			{
				switch (position){
					case 0:
					Intent intent = new Intent ( MainActivity.this,exodus14_14.class);
						startActivity(intent);
					break;
					
						case 1:
							Intent pro = new Intent ( MainActivity.this,proverb16_3.class);
							startActivity(pro);
							break;
							
						case 2:
							Intent fcor = new Intent ( MainActivity.this,fcorinthians10_13.class);
							startActivity(fcor);
							break;
							
						case 3:
							Intent prov = new Intent ( MainActivity.this,proverb3_5.class);
							startActivity(prov);
							break;
							
						case 4:
							Intent phil = new Intent ( MainActivity.this,philppians4_13.class);
							startActivity(phil);
							break;
							
							
					
				}
			}
			
			
		});
		
    }
	
	
}
