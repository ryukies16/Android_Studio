package com.Exer4HerodaMarvinTerence;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;

public class proverb3_5 extends Activity
	{
		
		ImageView proverbs;

		@Override
		protected void onCreate(Bundle savedInstanceState)
			{
				// TODO: Implement this method
				super.onCreate(savedInstanceState);
				setContentView(R.layout.proverb35);
				proverbs = findViewById(R.id.prov35);
				
				
			}
			public void onproverbs (View view)
			{
				Toast.makeText(this," God's strenght is our strenghts " ,Toast.LENGTH_LONG).show();
			}


	}

