package com.add;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.add.MainActivity;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity 
{
	TextView Class;
	TextView tvCases, tvRecovered, tvCritical, tvActive, tvTodayCases, tvTotalDeaths, tvTodayDeaths, tvAffectedCountries;


    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		tvCases = (TextView) findViewById(R.id.tvCases);
		tvRecovered = (TextView) findViewById(R.id.tvRecovered);
		tvCritical = (TextView) findViewById(R.id.tvCritical);
		tvActive = (TextView) findViewById(R.id.tvActive);
		tvTodayCases = (TextView) findViewById(R.id.tvTodayCases);
		tvTotalDeaths = (TextView) findViewById(R.id.tvTotalDeaths);
		tvTodayDeaths = (TextView) findViewById(R.id.tvTodayDeaths);
		tvAffectedCountries = (TextView) findViewById(R.id.tvAffectedCountries);


       

		fetchdata();

        /*

		 To use AIDEUtils, create an instance of it in your activity and then you can use the functions defined in that class

		 for example, to create a simple toast using AIDEUtils, do this :

		 AIDEUtils utils = new AIDEUtils(getApplicationContext());
		 utils.toast("Simple Short Toast");

		 OR, you can use the following way :

		 private AIDEUtils utils;

		 *In onCreate*

		 utils = new AIDEUtils(getApplicationContext());
		 utils.toast("Simple Short Toast");

		 */

    }

	private void fetchdata()
	{
		// Create a String request using Volley Library 

		String url =" http://disease.sh/v3/covid-19/all";

		StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

				@Override
				public void onResponse(String Response)
				{
					// Handle the JSON object and handle it inside try and catch 

					try { 
						// Creating object of JSONObject 
						JSONObject jsonObject = new JSONObject(p1.toString()); 
						tvCases.setText(jsonObject.getString("cases")); 
						tvRecovered.setText(jsonObject.getString("recovered")); 
						tvCritical.setText( jsonObject.getString("critical")); 
						tvActive.setText( jsonObject.getString("active")); 
						tvTodayCases.setText( jsonObject.getString("todayCases")); 
						tvTotalDeaths.setText( jsonObject.getString("deaths")); 
						tvTodayDeaths.setText( jsonObject.getString("todayDeaths")); 
						tvAffectedCountries.setText( jsonObject.getString("affectedCountries")); 
					} 
					catch (JSONException e) { 
						e.printStackTrace(); 
					} 
				}


			}, 
			new Response.ErrorListener() { 
				@Override
				public void onErrorResponse(VolleyError error) 
				{ 
					Toast.makeText(MainActivity.this,error.getMessage(),Toast.LENGTH_SHORT).show();
				} 
			}); 

		RequestQueue requestQueue = Volley.newRequestQueue(this); 
		requestQueue.add(request); 

	}
}
