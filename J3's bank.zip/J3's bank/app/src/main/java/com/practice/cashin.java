package com.practice;

import android.app.*;
import android.os.*;

public class cashin extends Activity
	{
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.cash_in);

			}
	}

