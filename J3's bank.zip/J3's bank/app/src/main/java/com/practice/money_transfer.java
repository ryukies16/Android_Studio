package com.practice;
import android.app.*;
import android.os.*;
import android.system.*;

public class money_transfer extends Activity
{
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.money_transfer);
	
}
}
