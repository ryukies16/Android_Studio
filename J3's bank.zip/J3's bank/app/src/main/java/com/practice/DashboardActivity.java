package com.practice;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import android.widget.*;

public class DashboardActivity extends AppCompatActivity {

		String EmailHolder;
		TextView Email, Balance;
		ImageView trans,bills,cin,cout,load;
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.dashboard);
 
				trans = (ImageView)findViewById(R.id.transfer);
				bills = (ImageView)findViewById(R.id.bills);
				cin = (ImageView)findViewById(R.id.cashin);
				cout = (ImageView)findViewById(R.id.cashout);
				load = (ImageView)findViewById(R.id.buyload);
				Balance = (TextView)findViewById(R.id.balance)                                                       ;
				
				trans.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									if(p1.equals(trans)){
									Intent intent = new Intent(DashboardActivity.this,money_transfer.class);
									startActivity(intent);
									}
								}
							
					
				});
				
				bills.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,pay_bills.class);
									startActivity(intent);
								}


						});
						
				cin.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,cashin.class);
									startActivity(intent);
								}


						});
						
				cout.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,cashout.class);
									startActivity(intent);
								}


						});
						
				load.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									Intent intent = new Intent(DashboardActivity.this,buyload.class);
									startActivity(intent);
								}


						});
						
						

			}


	}

