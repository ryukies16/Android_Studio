package com.practice;

import android.app.*;
import android.os.*;
import android.widget.*;
import com.google.firebase.database.*;
import android.view.*;

public class buyload  extends Activity
	{
		Button b10,b20,b30,b50,b100,b200,b250,b500,b1000,bsubmit;
		EditText ed;
		TextView txt;
		FirebaseDatabase db = FirebaseDatabase.getInstance();
		DatabaseReference load = db.getReference();
		
		
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.buy_load);
				ed =findViewById(R.id.editxt1);
				
				txt =findViewById(R.id.txt1);
				
				b10 = (Button)findViewById(R.id.btn10);
				b20 = (Button)findViewById(R.id.btn20);
				b30 = (Button)findViewById(R.id.btn30);
				b50 = (Button)findViewById(R.id.btn50);
				b100 = (Button)findViewById(R.id.btn100);
				b200 = (Button)findViewById(R.id.btn200);
				b250 = (Button)findViewById(R.id.btn250);
				b500 = (Button)findViewById(R.id.btn500);
				b1000 = (Button)findViewById(R.id.btn1000);
				bsubmit= (Button)findViewById(R.id.btnsub)                                                    ;
				
				b10.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"10");
								}
							
					
				});
						
				b20.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"20");
								}


						});
						
				b30.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"30");
								}


						});
						
				b50.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"50");
								}


						});
						
				b100.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"100");
								}


						});
						
						
				b200.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"200");
								}


						});
						
				b250.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"250");
								}


						});
						
				b500.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"500");
								}


						});
						
				b1000.setOnClickListener(new View.OnClickListener(){

							@Override
							public void onClick(View p1)
								{
									txt.setText(txt.getText()+"1000");
								}


						});
			}
	}
