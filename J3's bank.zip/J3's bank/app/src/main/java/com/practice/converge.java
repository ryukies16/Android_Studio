package com.practice;


import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.*;
import android.content.*;

public class converge extends Activity
	{

		public static void setOnClickListener(Object onClick)
			{
				// TODO: Implement this method
			}
		@Override
		protected void onCreate(Bundle savedInstanceState) {
				super.onCreate(savedInstanceState);
				setContentView(R.layout.converge);





			}
	}
